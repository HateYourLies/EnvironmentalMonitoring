create
    definer = env@`%` procedure drop_table()
BEGIN
    DECLARE i INT;
    SET i = 1;
    WHILE
				i < 32 DO
            SET @dropSQL = concat( 'drop table env_detail_', i, ';' );
        SELECT @dropSQL;
        PREPARE tmt
        FROM @dropSQL;
        EXECUTE tmt;
        DEALLOCATE PREPARE tmt;
        SET i = i + 1;
    END WHILE;
END;

