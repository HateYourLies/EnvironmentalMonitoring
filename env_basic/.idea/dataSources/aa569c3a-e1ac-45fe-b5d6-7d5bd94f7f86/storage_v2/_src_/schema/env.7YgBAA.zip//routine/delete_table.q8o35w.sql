create
    definer = env@`%` procedure delete_table()
BEGIN
    DECLARE i INT;
    SET i = 1;
    WHILE
				i < 32 DO
            SET @deleteSQL = concat( 'delete from env_detail_', i, ';' );
        SELECT @deleteSQL;
        PREPARE tmt FROM @deleteSQL;
        EXECUTE tmt;
        DEALLOCATE PREPARE tmt;
        SET i = i + 1;
    END WHILE;
END;

